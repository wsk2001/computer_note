﻿using System;

class Program
{
    static void Main(string[] args)
    {
        string msg = string.Empty;

        /*
        while (true)
        {
            msg = Console.ReadLine();

            EchoClient echo = new EchoClient();
            echo.Process(4490, msg);
        }
        */

        while (true)
        {
            msg = Console.ReadLine();

            EchoSslClient echo = new EchoSslClient();
            echo.Process(4490, "testserver.com", msg);
        }
    }
}


