﻿using System;
using System.Net.Sockets;
using System.Text;

class EchoClient
{
    internal void Process(int port, string msg)
    {
        using (TcpClient client = new TcpClient("127.0.0.1", port))
        {
            NetworkStream ns = client.GetStream();

            byte[] buf = Encoding.ASCII.GetBytes(msg);
            ns.Write(buf, 0, buf.Length);

            buf = new byte[4096];
            int readLen = ns.Read(buf, 0, 4096);
            Console.WriteLine(Encoding.ASCII.GetString(buf, 0, readLen));
        }
    }
}

