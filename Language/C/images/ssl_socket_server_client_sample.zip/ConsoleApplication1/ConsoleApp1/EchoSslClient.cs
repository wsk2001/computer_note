﻿using System;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;

class EchoSslClient
{
    internal void Process(int port, string certName, string msg)
    {
        using (TcpClient client = new TcpClient("127.0.0.1", port))
        using (SslStream sslStream = new SslStream(client.GetStream(), false,
                validateCertificate, null))
        {
            try
            {
                sslStream.AuthenticateAsClient(certName);
            }
            catch (AuthenticationException e)
            {
                Console.WriteLine(e.ToString());
                return;
            }

            byte[] buf = Encoding.ASCII.GetBytes(msg);
            sslStream.Write(buf, 0, buf.Length);
            sslStream.Flush();

            buf = new byte[4096];
            int readLen = sslStream.Read(buf, 0, 4096);
            Console.WriteLine(Encoding.ASCII.GetString(buf, 0, readLen));
        }
    }

    private bool validateCertificate(object sender, X509Certificate certificate, X509Chain chain,
        SslPolicyErrors sslPolicyErrors)
    {
        if (sslPolicyErrors == SslPolicyErrors.None)
        {
            return true;
        }

#if DEBUG
        if (sslPolicyErrors == SslPolicyErrors.RemoteCertificateChainErrors)
        {
            if (chain.ChainStatus.Length == 1)
            {
                if (chain.ChainStatus[0].Status == X509ChainStatusFlags.UntrustedRoot)
                {
                    return true;
                }
            }
        }
#endif

        Console.WriteLine("validateCertificate: {0}", sslPolicyErrors);
        return false;
    }
}
