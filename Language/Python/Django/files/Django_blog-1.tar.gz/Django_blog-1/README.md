# Django_blog
A blog application made on Django 2.

![ezgif com-video-to-gif](https://user-images.githubusercontent.com/38559396/55287491-12c4de80-53c7-11e9-8c6a-3f02b79ba9ca.gif)

To learn more read https://djangocentral.com/building-a-blog-application-with-django
