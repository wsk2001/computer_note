
// David Pinch (davepinch@gmail.com)
// Copyright (c) 2006-2007 David Pinch.
// Use freely for any purpose, commercial or otherwise.

using System;
using System.IO;
using System.Runtime.InteropServices;

namespace Thought.Research
{

    /// <summary>
    ///     This class allocates a block of memory from the kernel,
    ///     then offers the ability to protect it from modification.
    ///     No other process (or object) can then modify the memory.
    ///     To use, create a buffer (specifying its length), then
    ///     call GetStream.  Call Protect() to stop the memory from
    ///     being modified.
    /// </summary>
    public class ProtectedBuffer : IDisposable
    {

        // The MEM constants are passed to the Win32
        // VirtualAlloc and VirtualFree functions.  They
        // define the type of memory operation to perform (e.g.
        // release memory).

        private const int MEM_COMMIT   = 0x1000;
        private const int MEM_DECOMMIT = 0x4000;
        private const int MEM_RELEASE  = 0x8000;

        // The PAGE constants are used with the VirtualProtect
        // function.  They define the access rights to a chunk
        // of virtual memory.

        private const int PAGE_NOACCESS          = 0x001;
        private const int PAGE_READONLY          = 0x002;
        private const int PAGE_READWRITE         = 0x004;
        private const int PAGE_WRITECOPY         = 0x008;
        private const int PAGE_EXECUTE           = 0x010;
        private const int PAGE_EXECUTE_READ      = 0x020;
        private const int PAGE_EXECUTE_READWRITE = 0x040;
        private const int PAGE_EXECUTE_WRITECOPY = 0x080;
        private const int PAGE_GUARD             = 0x100;
        private const int PAGE_NOCACHE           = 0x200;


        // The VirtualAlloc function reserves a region of 
        // memory pages in the calling process.  If the starting
        // address is zero/null (first parameter), the OS
        // decides where to allocate the region. Note: memory
        // is allocated in pages; refer to the Platform SDK for
        // details.  A zero/null return value indicates failure.

        [DllImport("kernel32", SetLastError = true)]
        internal static extern IntPtr VirtualAlloc(
            IntPtr lpStartAddr,
            UIntPtr size,
            uint flAllocationType,
            uint flProtect);


        // VirtualFree releases/decommits the memory pages allocated by 
        // a call to VirtualAlloc.  When releasing, the dwSize
        // value must be zero.  A return value of zero indicates
        // failure.

        [DllImport("kernel32", SetLastError=true)]
        private static extern int VirtualFree(
            IntPtr lpAddress,
            UInt32 dwSize,
            UInt32 dwFreeType);


        // The VirtualProtection function sets the access/permission
        // attributes of a block of memory previously allocated by
        // VirtualAlloc.  A return value of zero indicates failure.

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern int VirtualProtect(
            IntPtr lpAddress,
            uint dwSize,
            uint flNewProtect,
            out uint lpflOldProtect);


        // Private fields...

        // The 'baseAddress' field holds the address of the
        // buffer allocated by the VirtualAlloc function.
        // The buffer is created in the constructor.

        protected IntPtr baseAddress;
        
        
        // The 'disposed' field tracks whether the class has been
        // disposed (e.g. whether it has destroyed unmanaged resources).

        private bool disposed;
        
        
        // The 'length' field tracks the desired length of the
        // buffer.  This is passed by the user to the constructor.
        // This version of the class does not support resizing
        // of the buffer.

        protected long length;
        
        
        // The oldProtection field is populated by VirtualProtect.
        // It contains the original access permissions of the
        // memory chunk affected by the call.

        private uint oldProtection;


        // The default constructor is marked as private to ensure
        // that only the parameterized constructor is called.  The
        // caller must specify a desired buffer length.

        private ProtectedBuffer() { }


        // Initializes a buffer of the desired length.  No error
        // handling here...

        public ProtectedBuffer(long length)
        {

            if (length < 1)
                throw new ArgumentOutOfRangeException("length");

            this.length = length;

            // Allocate the desired memory.  The first parameter
            // specifies the address; if null/zero, the system
            // decides where to locate the memory.

            baseAddress = VirtualAlloc(
                IntPtr.Zero,
                (UIntPtr)length,
                MEM_COMMIT,
                PAGE_EXECUTE_READWRITE);

        }

        ~ProtectedBuffer()
        {
            Dispose(false);
        }


        public void Dispose()
        {

            Dispose(true);

            // Don't waste time calling the finalizer/deconstructor.

            GC.SuppressFinalize(this);
        }



        protected virtual void Dispose(bool disposing)
        {

            // If disposing is true, the method was called
            // directly by the user.  If false, the method was
            // called from the finalizer.

            if (!this.disposed)
            {

                try
                {

//                    Unprotect();

                    // The length (second parameter) must be zero
                    // if the memory is being released.  A return
                    // value of zero indicates failure.

                    int result = VirtualFree(
                        baseAddress,
                        0,
                        MEM_DECOMMIT | MEM_RELEASE);


                }
                catch
                {

                    // Hmm... ignore?  I guess I don't know the
                    // best practices well enough to answer...
                }

                this.disposed = true;

            }

        }


        // The GetStream method returns a stream capable of
        // reading and writing to the allocated buffer.

        public Stream GetStream()
        {

            unsafe
            {

                if (this.disposed)
                    throw new ObjectDisposedException("this");

                byte* memoryPointer = (byte*)baseAddress.ToPointer();

                // The UnmanagedMemoryStream class provides a convenient
                // way of allowing the user to access the buffer.  Technically,
                // if the buffer has been protected from modification via a 
                // prior call to Protect(), then the returned stream should be
                // set as read-only.  However, by returning a read/write stream,
                // the protection can be "proved".

                UnmanagedMemoryStream stream = new UnmanagedMemoryStream(
                    memoryPointer,
                    length,
                    length,
                    FileAccess.ReadWrite);

                return stream;
            }


        }


        
        // The Protect() method makes the buffer read-only.
        // Any streams that were created by GetStream() will
        // fail upon a write.

        public void Protect()
        {

            if (this.disposed)
                throw new ObjectDisposedException("this");

            // Tell the OS to mark the memory pages as read only.
            // Multiple calls should not be a problem.  A return
            // value of zero indicates failure.

            int result = VirtualProtect(
                baseAddress,
                (uint)length,
                PAGE_READONLY,
                out oldProtection);

            if (result == 0)
            {

                // Throw some exception here...
                // I'm lazy.

                int lastErrorCode = Marshal.GetLastWin32Error();

            }

        }



        // The Unprotect() method marks the buffer as read/write.
        // Multiple calls are not a problem.  All streams created in
        // the past, or the future, will now be read/write.

        public void Unprotect()
        {

            if (this.disposed)
                throw new ObjectDisposedException("this");

            int result = VirtualProtect(
                baseAddress,
                (uint)length,
                oldProtection,
                out oldProtection);

            if (result == 0)
            {

                // A return value of zero indicates failure.
                // A non-lazy programmer would raise an exception.
                // Unfortunately I am lazy.

            }

        }

    }
}
