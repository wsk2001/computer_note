﻿using System;
using System.Runtime.InteropServices;
using System.IO;

namespace Thought.Research
{
	/// <summary>
	/// Extension of ProtectedBuffer 
	/// added functionality to allocate physical memory
	/// that doesn't get paged to the Windows swapfile.
	/// 
	/// Idea based on ProtectedBuffer code available @
	/// http://www.thoughtproject.com/Snippets/ProtectedBuffer/
	/// 
	/// Additional notes;
	/// <item>
	///   Stuff stays in memory based on it's thread;
	///   http://blogs.msdn.com/b/oldnewthing/archive/2007/11/06/5924058.aspx
	/// </item>
	/// </summary>
	public class AweBuffer: ProtectedBuffer
	{		
		bool disposed = false;
		static bool initialized = false;
		
		public AweBuffer(long length): base(length)
		{
			if (!initialized)
			{
				initialized = true;

				// Optimization for Vista and better;
				OperatingSystem os = Environment.OSVersion;
				if (os.Platform == PlatformID.Win32NT && os.Version.Major > 6)
				{
					Kernel32.SetProcessWorkingSetSizeEx(
						System.Diagnostics.Process.GetCurrentProcess().Handle,
						1024 * 1024 * 2, // min 2 Mb
						1024 * 1024 * 50 , // reserve 50 Mb (we'll allow for growing)
						Kernel32.QUOTA_LIMITS_HARDWS_MAX_DISABLE & Kernel32.QUOTA_LIMITS_HARDWS_MIN_ENABLE); // Demand a minimum, but don't limit us to the maximum :)
				}
			}
			
			Kernel32.VirtualLock(
				baseAddress, 
				(UIntPtr)length);
		}
				
		protected override void Dispose(bool disposing)
	    {
	        if (!disposed)
	        {
	            // Release unmanaged resources.
	            // Set large fields to null.
				Kernel32.VirtualUnlock(
	            	baseAddress, 
	            	(UIntPtr)length);

	            disposed = true;
	        }
	        base.Dispose(disposing);
	    }
	}
}
