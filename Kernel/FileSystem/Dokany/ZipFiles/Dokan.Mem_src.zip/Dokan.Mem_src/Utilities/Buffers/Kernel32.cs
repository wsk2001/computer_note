﻿using System;
using System.Runtime.InteropServices;

namespace System.Runtime.InteropServices
{
	/// <summary>
	/// Collection of p/invokes to kernel32.dll
	/// 
	/// See http://www.pinvoke.net
	/// </summary>
	public static class Kernel32
	{
		public const int QUOTA_LIMITS_HARDWS_MIN_ENABLE = 0x00000001;
		public const int QUOTA_LIMITS_HARDWS_MIN_DISABLE = 0x00000002;
		public const int QUOTA_LIMITS_HARDWS_MAX_ENABLE = 0x00000004;
		public const int QUOTA_LIMITS_HARDWS_MAX_DISABLE = 0x00000008;
		
		[DllImport("kernel32.dll")]
		public static extern bool VirtualLock(IntPtr lpAddress, UIntPtr dwSize);
		
		[DllImport("kernel32.dll")]
		public static extern bool VirtualUnlock(IntPtr lpAddress, UIntPtr dwSize);
		
		[DllImport("kernel32.dll")] // http://msdn.microsoft.com/en-us/library/ms686237(v=VS.85).aspx
		public static extern bool SetProcessWorkingSetSizeEx(IntPtr hProcess, int dwMinimumWorkingSetSize, int dwMaximumWorkingSetSize, int Flags);
	}
}
