﻿using System;
using System.IO;
using Thought.Research;

namespace DokanMem
{
    /// <summary>
    /// Represents a file in memory, based on MemoryStreams
    /// This is the base-class from which the file & folder
    /// are derived
    /// </summary>
    class AweMemoryFile : MemoryFile
    {
        AweBuffer _content;
        long _occupied;
        long _allocationSize;

        internal AweMemoryFile(MemoryFolder parent, string name)
            : base(parent, name)
        {
        	_occupied = 0;
        	_allocationSize = 4096;        	
        	_content = new AweBuffer(_allocationSize);
        	
            Attributes = FileAttributes.Normal
                & FileAttributes.NotContentIndexed;
        }

        internal override long Size
        {
        	get { return _occupied; }
			set 
			{ 				
				// allocate more if we have to,
				if (value > _allocationSize)
				{
					// AweBuffer can't be resized yet,
					// so copy it's contents to a larger one.
					Stream oldStream = _content.GetStream();
					AweBuffer newContent = new AweBuffer(value);
					Stream newStream = newContent.GetStream();					
					
					byte[] buffer = new byte[32768];
				    while (true)
				    {
				        int amountRead = oldStream.Read (buffer, 0, buffer.Length);
				        if (amountRead <= 0)
				            break;
				        newStream.Write (buffer, 0, amountRead);
				    }
				    
				    _content.Dispose();
				    _content = newContent;
				    _allocationSize = value;
				}				
				
				// but don't shrink the buffer once it's allocated
				
			    _occupied = value;
			}
        }
        
        internal override uint Write(long offset, byte[] buffer)
        {
            Stream writeStream = _content.GetStream();
            writeStream.Seek(offset, SeekOrigin.Begin);
            writeStream.Write(buffer, 0, buffer.Length);
            return (uint)buffer.Length;
        }
        
        internal override uint Read(long offset, byte[] buffer)
        {
        	Stream readStream = _content.GetStream();
            readStream.Seek(offset, SeekOrigin.Begin);
            return (uint)readStream.Read(buffer, 0, buffer.Length);
        }
    }
}
