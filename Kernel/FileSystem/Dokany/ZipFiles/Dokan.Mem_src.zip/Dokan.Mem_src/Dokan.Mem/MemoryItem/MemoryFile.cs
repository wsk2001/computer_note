﻿using System;
using System.IO;
using Thought.Research;

namespace DokanMem
{
    internal abstract class MemoryFile : MemoryItem
    {
    	protected MemoryFile(MemoryFolder parent, string name)
    		: base (parent, name)
    	{    		
    	}
    	
        internal abstract long Size
        {
        	get;
			set; 
        }
        
        internal abstract uint Write(long offset, byte[] buffer);
        internal abstract uint Read(long offset, byte[] buffer);
        
        internal static bool UseMemStream;
        internal static MemoryFile New(MemoryFolder parent, string name)
        {
        	if (UseMemStream)
        		return new MemoryStreamFile(parent, name);
        	else
        		return new AweMemoryFile(parent, name);        	
        }
    }
}
