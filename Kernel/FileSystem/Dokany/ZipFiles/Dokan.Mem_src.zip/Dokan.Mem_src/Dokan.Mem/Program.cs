using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.ComponentModel;
//using System.Threading.Tasks; // when it's moved to .NET 4 :)
using Dokan;

namespace DokanMem
{
    #warning PROTOTYPING GRADE CODE - do not use in a production environment
    // TODO implement locking (not threadsafe yet)
    // TODO implement list that tracks open files, and their access-rights
    // TODO add a decent error-handler

    class Program
    {
        static NotifyIcon _notifyIcon;
        static BackgroundWorker _dokanWorker;
        
        // a driveletter where we can mount (we start checking from D: forward)
        readonly static char _driveLetter = UtilityMethods.GetFirstAvailableDriveLetter();

		[STAThread()]
		static void Main(string[] args)
		{
		    // Set us up a tray-icon to interact with the user;
		    SetupNotifyIcon();
		    
		    // Set to false if you want to test with the AweBuffers 
		    // instead of a MemoryStream
		    MemoryFile.UseMemStream = true;

	        // run the dokan-task
            _dokanWorker = new BackgroundWorker();
            _dokanWorker.DoWork += delegate { 
                DokanOptions options = new DokanOptions
                {
                    DriveLetter = _driveLetter, 
                    DebugMode = true, 
                    UseStdErr = true,
                    NetworkDrive = false, 
                    Removable = false,          // provides an "eject"-menu to unmount
                    UseKeepAlive = true,        // auto-unmount
                    ThreadCount = (ushort) (System.Diagnostics.Debugger.IsAttached ? 1 : 0), // limit to one thread during debugging!
                    VolumeLabel = "Dokan.RAM"
                };
                DokanNet.DokanMain(options, new DokanMemoryStreamOperations());
            };
        	_dokanWorker.RunWorkerAsync();
        	
        	// kick ui-thread
        	Application.Run();
        }

        #region NotifyIcon
        static void SetupNotifyIcon()
        {
            MenuItem[] menuItems = new MenuItem[2];
            menuItems[0] = new MenuItem("&Explore", OnStartExplorer);
            menuItems[1] = new MenuItem("E&xit", OnExit);
            
            _notifyIcon = new NotifyIcon();
            _notifyIcon.Text = String.Format("Dokan.RAM on {0}:\\", _driveLetter);
            _notifyIcon.Icon = IconGenerator.CreateIcon(_driveLetter, System.Drawing.Color.Green);
            _notifyIcon.ContextMenu = new ContextMenu(menuItems);
            _notifyIcon.DoubleClick += OnStartExplorer;
            _notifyIcon.Visible = true;
        }
        static void OnStartExplorer(object sender, EventArgs e)
        {
            // See http://support.microsoft.com/kb/152457 for a list of command-line args
            // that are supported by Windows Explorer.

            string explorerArgs = string.Format("/e,{0}:\\", _driveLetter);
            System.Diagnostics.Process.Start("explorer.exe", explorerArgs);
        }
        static void OnExit(object sender, EventArgs e)
        {
            _notifyIcon.Visible = false;
            Application.Exit();
        }
        #endregion
    }
}
