#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>

#include "nativeso_NativeSO.h"


JNIEXPORT jstring JNICALL Java_nativeso_NativeSO_javaHello
  (JNIEnv *env, jclass jcla, jstring name)
{
	jstring result = NULL;
	static char Buff[ 1024 ];

	const  char *pName = (*env)->GetStringUTFChars(env,name, NULL);
	
	memset( Buff, 0x00, sizeof(Buff) );
	sprintf( Buff, "Hello %s!", pName);
	result = (*env)->NewStringUTF(env, Buff);
	
	(*env)->ReleaseStringUTFChars(env, name,  pName);
	
	 return result;
}
	

