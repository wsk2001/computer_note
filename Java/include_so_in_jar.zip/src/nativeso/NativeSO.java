package  nativeso;

import java.io.*;
import java.util.*;

public class NativeSO {

    private static String _sLoadLibruryError = "";

    private NativeSO()
    {
		 
    }

    public static native String javaHello( String name );

    public static String sayHello( String name )
    {        
        String str = javaHello( name ); 
        return str;
    }

    static {
        try {
          System.loadLibrary("NativeSO");
        }catch (UnsatisfiedLinkError e) {
        	try {
				String osArch = getOsArch();
				
				if( "Windows64".startsWith(osArch) )
				{
					NativeUtils.loadLibraryFromJar("/nativeso/SO/Windows64/NativeSO.dll");
				}
				else if("Linux64".startsWith(osArch))
				{
					NativeUtils.loadLibraryFromJar("/nativeso/SO/Linux64/libNativeSO.so");
				}
				else
				{
					System.out.println("Can not Support OS " + osArch );
					System.exit(-1);
				}
            	 
        	} catch (IOException e1) {
            	throw new RuntimeException(e1);
        	}
    	}
    }
	
	public static final String getOsArch() {
		String osName = System.getProperty("os.name");
		String osAndArch = "";
		
		if (osName.startsWith("Linux")) {
            if ("dalvik".equals(System.getProperty("java.vm.name").toLowerCase())) {
                osAndArch = "Android";
            }
            else {
                osAndArch = "Linux";
            }
        }
        else if (osName.startsWith("AIX")) {
            osAndArch = "Aix";
        }
        else if (osName.startsWith("Mac") || osName.startsWith("Darwin")) {
            osAndArch = "Mac";
        }
        else if (osName.startsWith("Windows CE")) {
            osAndArch = "WinCE";
        }
        else if (osName.startsWith("Windows")) {
            osAndArch = "Windows";
        }
        else if (osName.startsWith("Solaris") || osName.startsWith("SunOS")) {
            osAndArch = "Solaris";
        }
        else if (osName.startsWith("FreeBSD")) {
            osAndArch = "FreeBSD";
        }
        else if (osName.startsWith("OpenBSD")) {
            osAndArch = "OpenBSD";
        }
        else if (osName.equalsIgnoreCase("gnu")) {
            osAndArch = "gnu";
        }
        else if (osName.equalsIgnoreCase("gnu/kfreebsd")) {
            osAndArch = "kfreebsd";
        }
        else if (osName.equalsIgnoreCase("netbsd")) {
            osAndArch = "netbsd";
        }
        else {
            osAndArch = "Unspecified";
        }	

		String osBit = "";
		String model = System.getProperty("sun.arch.data.model",
                                          System.getProperty("com.ibm.vm.bitmode"));
        if (model != null) {
           if( "64".equals(model) == true )
		   {
			   osBit = "64";
		   }
		   else
		   {
			   osBit = "32";
		   }
        }
		else
		{
			String ARCH = System.getProperty("os.arch");
			if(	"x86-64".equals(ARCH)   || "ia64".equals(ARCH)    || 
			    "ppc64".equals(ARCH)    || "ppc64le".equals(ARCH) || 
				"sparcv9".equals(ARCH)  || "mips64".equals(ARCH)  || 
				"mips64el".equals(ARCH) || "amd64".equals(ARCH)) {
				osBit = "64";
		   }
		   else
		   {
			   osBit = "32";
		   }
		}
		
		osAndArch = osAndArch + osBit;
					
		return osAndArch;
	}	
}

