import static nativeso.NativeSO.*;

public class HelloJniTest
{
	public static void main(String[] args)
	{
		String msg = "";
		
		try
		{
			msg = sayHello("World");
			System.out.println("So Call Test : " + msg );
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}

